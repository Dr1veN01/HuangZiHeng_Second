function getArticleByKeyWord(url, val) {
    // 创建xmlhttp对象
    var searchBody = document.querySelector("#searchBody");
    var searchEmpty = document.querySelector("#searchEmpty");
    searchBody.innerHTML = "";
    searchEmpty.style.display = "none";
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/search/getArticleByKeyWord?keyWord=" + val + "&page=1&size=5");
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var status = JSON.parse(xmlhttp.responseText).status;
            var arr = JSON.parse(xmlhttp.responseText).data.articleList;
            if (status == 400) {
                searchEmpty.style.display = "block"
                return;
            }
            for (let i = 0; i < arr.length; i++) {
                var ul = document.createElement("ul");
                ul.setAttribute("articleId", arr[i].articleId)
                if (arr[i].img[0] == "" && arr[i].content !== "") {
                    console.log('ok');
                    ul.innerHTML = `
                <li class="content">${arr[i].content}</li>
                <li class="title">${arr[i].title}</li>
            `
                    searchBody.appendChild(ul);;
                } else {
                    var Src = arr[i].img[0];
                    var img = new Image()
                    img.src = Src;
                    img.className = "cover";
                    img.onload = function () {
                        waterfall("#searchBody", "#searchBody>ul");
                    }
                    ul.appendChild(img);
                    ul.innerHTML += `
                        <li class="title">${arr[i].title}</li> 
                    `
                    ul.addEventListener("click", function () {
                        let articledId = this.getAttribute("articleId")
                        getDetails(url, articledId)
                        document.querySelector("#searchSection").style.display = "block";
                        document.querySelector("#main").style.display = "none"
                    })
                    searchBody.appendChild(ul);;
                }
            }
        }
    }
}

function getArticleByLabel(url, val) {
    //创建xmlhttp对象
    var searchBody = document.querySelector("#searchBody");
    var searchEmpty = document.querySelector("#searchEmpty");
    searchBody.innerHTML = "";
    searchEmpty.style.display = "none";
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/search/getArticleByLabel?label=" + val + "&page=1&size=3");
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var status = JSON.parse(xmlhttp.responseText).status;
            var arr = JSON.parse(xmlhttp.responseText).data.articleList;
            if (status == 400) {
                searchEmpty.style.display = "block"
                return;
            }
            // 向searchBody里添加元素
            for (let i = 0; i < arr.length; i++) {
                var ul = document.createElement("ul");
                ul.setAttribute("articleId", arr[i].articleId)
                ul.setAttribute("authorId", arr[i].authorId)
                var Src = arr[i].cover;
                var img = new Image()
                img.src = Src;
                img.className = "cover";
                img.onload = function () {
                    waterfall("#searchBody", "#searchBody>ul");
                }
                ul.appendChild(img);
                if (!arr[i].avatar) {
                    arr[i].avatar = "./img/noavater.jpg"
                }
                ul.innerHTML += `
                        <li class="title">${arr[i].title}</li>
                        <ul class="avatar">
                            <li><img src="${arr[i].avatar}"></img></li>
                            <li class="username">${arr[i].username}</li>
                            <li class="fanNum">${arr[i].fanNum}</li>
                        </ul> 
                    `

                searchBody.appendChild(ul);;

            }
        }
    }
}

function getUser(url, val) {
    //创建xmlhttp对象
    var searchBody = document.querySelector("#searchBody");
    var searchEmpty = document.querySelector("#searchEmpty");
    searchBody.innerHTML = "";
    searchEmpty.style.display = "none";
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/search/getUser?keyWord=" + val + "&page=1&size=3");
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var status = JSON.parse(xmlhttp.responseText).status;
            var arr = JSON.parse(xmlhttp.responseText).data.userList;
            if (status == 400) {
                searchEmpty.style.display = "block"
                return;
            }
            for (let i = 0; i < arr.length; i++) {
                let ul = document.createElement("ul");
                ul.setAttribute("authorId", arr[i].authorId)
                if (!arr[i].avatar) {
                    arr[i].avatar = "./img/noavater.jpg"
                }
                ul.innerHTML += `
                        <ul class="avatar">
                            <li style="height:5vh;width:5vh;border-radius:5vh"><img src="${arr[i].avatar}"></img></li>
                            <li class="username" style="line-height:2.5rem;padding-left:1vw">${arr[i].username}</li>
                            <li class="intro" style="line-height:2.5rem;">${arr[i].intro}</li>
                        </ul> 
                    `
                searchBody.appendChild(ul);
            }
        }
    }
}

function getLabel(url, val) {
    //创建xmlhttp对象
    var searchBody = document.querySelector("#searchBody");
    var searchEmpty = document.querySelector("#searchEmpty");
    searchBody.innerHTML = "";
    searchEmpty.style.display = "none";
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/search/getLabel?keyWord=" + val + "&page=1&size=3");
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var status = JSON.parse(xmlhttp.responseText).status;
            var arr = JSON.parse(xmlhttp.responseText).data.labelList;
            if (status == 400) {
                searchEmpty.style.display = "block"
                return;
            }
            for (let i = 0; i < arr.length; i++) {
                var ul = document.createElement("ul");
                ul.setAttribute("authorId", arr[i].authorId)
                ul.innerHTML += `
                        <li style="width:100%;height:4vh;line-height:4vh;font-size:15px border">#${arr[i]}</li>
                    `
                ul.addEventListener("click", function () {
                    let label = this.innerText.slice(1);
                    getArticleByLabel(url, label);
                })
                searchBody.appendChild(ul);
            }
        }
    }
}