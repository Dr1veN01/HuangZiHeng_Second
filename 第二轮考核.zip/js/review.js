function getReviewsByArt(url, articleId) {
    let xmlhttp = new XMLHttpRequest();
    var allCmt = document.querySelector(".allCmt ul");
    let str = "";
    xmlhttp.open("GET", url + "/review/getReviewsByArt?articleId=" + articleId + "&page=1&size=3", true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            // console.log(JSON.parse(xmlhttp.responseText));
            var allreview = JSON.parse(xmlhttp.responseText).list;

            if (allreview.length == 0) {
                let li = document.createElement("li");
                li.classList = "noCmt"
                li.innerHTML = "暂时还没有评论，留下你的足迹吧"
                allCmt.appendChild(li)

            } else {
                //添加二级评论
                for (let i = 0; i < allreview.length; i++) {
                    let li = document.createElement("li")
                    if (!allreview[i].childrenReviews) {
                        allreview[i].childrenReviews = "";
                    } else {
                        for (let j = 0; j < allreview[i].childrenReviews.length; j++) {
                            if (!allreview[i].userInfo.avatar) {
                                allreview[i].userInfo.avatar = "./img/noavater.jpg"
                            }
                            str += `
                            <li>
                                <div class="avatar" authorId="${allreview[i].userInfo.uid}" style="margin-left:2vw;width:4vh;height:4vh;overflow:hidden;border-radius:4vh;"><img style="width:100%;height:100%;border:0;" src="${allreview[i].userInfo.avatar}"></div>
                                <div class="username">${allreview[i].userInfo.userName}</div>
                                <div>${allreview[i].childrenReviews[j].content}</div>                             
                            </li>
                        `
                        }

                    }

                    if (!allreview[i].userInfo.avatar) {
                        allreview[i].userInfo.avatar = "./img/noavater.jpg"
                    }
                    li.innerHTML = `
                        <div class="user">
                            <div class="avatar" authorId = ${allreview[i].userInfo.uid} style="margin-left:2vw"><img src="${allreview[i].userInfo.avatar}"></div>
                            <div class="username">${allreview[i].userInfo.userName}</div>
                            <div class="love">
                                <div class="ico iconfont">&#xe8ab;</div>
                                <p>${allreview[i].goodNum}</p>
                            </div>
                        </div>

                        <div class="inner">
                            ${allreview[i].content}
                        </div>
                        <div class="time">${allreview[i].time}</div>
                        <ul class="childrenReviews">${str}</ul>
                `

                    allCmt.appendChild(li)
                }
                let avatars = document.querySelectorAll(".avatar")
                for (let i = 0; i < avatars.length; i++) {
                    avatars[i].addEventListener("click", function () {
                        let ID = avatars[i].getAttribute("authorId")
                        author_getUserInfo(url, ID)
                        author_followList(url, ID)
                        author_fanList(url, ID)
                        document.querySelector("#main").style.display = "none";
                        document.querySelector("#searchLine").style.display = "none";
                        document.querySelector("#searchSection").style.display = "none";
                        document.querySelector("#login").style.display = "none";
                        document.querySelector("#downTags").style.display = "none";
                        document.querySelector("#details").style.display = "none"
                        document.querySelector("#authorMsg").style.display = "block"
                    })

                }

            }
        }
    }
}

function submitReview(url, content = 123, articleId, replyId) {
    if (!replyId) {
        let strjson = {
            "content": content,
            "articleId": articleId
        };
        let str = JSON.stringify(strjson)
        console.log(str);
    } else {
        let strjson = {
            "content": content,
            "articleId": articleId,
            "replyId": replyId
        };
        let str = JSON.stringify(strjson)
        console.log(str);
    }


    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("POSt", url + "/review/submitReview", true);
    xmlhttp.send(str)
    xmlhttp.onreadystatechange = function () {
        console.log("OK");
    }
}