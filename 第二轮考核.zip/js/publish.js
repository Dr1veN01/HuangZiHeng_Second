function addlabel(label) {
    var li = document.createElement("li");
    li.innerHTML = "#" + label;
    document.querySelector(".addLabel ul").appendChild(li);
    document.querySelector(".labelIpt input").value = "";
    document.querySelector(".labelIpt").style.display = "none"
}

function Publish(url, token, img, title, content, label = "二次元") {
    let lb = [];
    for (let i = 0; i < label.length; i++) {
        lb[i] = label[i].innerHTML.slice(1);
    }
    if (!token) {
        token = "";
    }
    let formdata = new FormData()
    for (let i = 0; i < img.length; i++) {
        formdata.append("img", img[i]);
    }
    formdata.append("label", lb);
    formdata.append("title", title);
    formdata.append("content", content);


    var xmlhttp = new XMLHttpRequest();

    xmlhttp.open("POST", url + "/article/publish", true);
    xmlhttp.setRequestHeader("Authorization", token)
    xmlhttp.send(formdata);
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            alert("上传成功!");
        }
    }
}