function loginCheck(url, token, articleId) {
    if (!token) {
        token = "";
    }
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/userInfo/checkLogin", true);
    xmlhttp.setRequestHeader("Authorization", token);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var status = JSON.parse(xmlhttp.responseText).status;
            if (status == 400) {
                document.querySelector("#mySection").style.display = "none";
                document.querySelector("#login").style.display = "block";
            } else if (status == 200) {
                document.querySelector("#login").style.display = "none";
                document.querySelector("#mySection").style.display = "block";
                getUserInfo(url, token, articleId);
                followList(url, token, articleId);
                fanList(url, token, articleId)
                getUserArticle(url, articleId)
            }
        }
    }
}


function login(url) {
    let formData = new FormData();
    let xmlhttp = new XMLHttpRequest();
    let username = document.querySelector("#form input[name=username");
    let password = document.querySelector("#form input[name=password");
    formData.append("username", username.value);
    formData.append("password", password.value);

    xmlhttp.open("POST", url + "/user/login", true);
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            if (JSON.parse(xmlhttp.responseText).status === 400) {
                alert("账号或密码错误!")
                // location.reload();
                username.value = "";
                password.value = "";
                return;
            }
            alert("登录成功");
            let token = JSON.parse(xmlhttp.responseText).data.token;
            console.log(token);
            let articleId = JSON.parse(xmlhttp.responseText).data.id;
            sessionStorage.setItem('articleId', articleId);
            sessionStorage.setItem('token', token);
            loginCheck(url, token, articleId);
            location.reload();
        }
    }
    xmlhttp.send(formData);
}

function getUserInfo(url, token, articleId) {
    if (token) {
        let xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET", url + "/userInfo/getUserInfo?", true);
        xmlhttp.setRequestHeader("Authorization", token);
        xmlhttp.send();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
                var data = JSON.parse(xmlhttp.responseText).data;
                document.querySelector("#article>.fav>img").src = data.avatar;
                if (!data.avatar) {
                    document.querySelector("#article>.fav>img").src = "./img/noavater.jpg";
                }
                document.querySelector("#article>aside>h3").innerHTML = data.username;
                document.querySelector("#article>aside>.articleId").innerHTML = "ID:" + articleId;
                return;
            }
        }
    }
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/userInfo/getUserInfo?id=" + articleId, true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var data = JSON.parse(xmlhttp.responseText).data;
            document.querySelector("#article>.fav>img").src = data.avatar;
            if (!data.avatar) {
                document.querySelector("#article>.fav>img").src = "./img/noavater.jpg";
            }
            document.querySelector("#article>aside>h3").innerHTML = data.username;
            document.querySelector("#article>aside>.articleId").innerHTML = "ID:" + articleId;
        }
    }
}

function followList(url, token, articleId) {
    if (token) {
        let xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET", url + "/follow/followList", true);
        xmlhttp.setRequestHeader("Authorization", token);
        xmlhttp.send();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
                var status = JSON.parse(xmlhttp.responseText).status;
                var follow = JSON.parse(xmlhttp.responseText).data;
                if (status == 400) {
                    document.querySelector("#list>.subscribe>p").innerHTML = "0";
                } else {
                    document.querySelector("#list>.subscribe>p").innerHTML = follow.length;
                }
                return;
            }
        }
    }
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/follow/followList?userId=" + articleId, true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var status = JSON.parse(xmlhttp.responseText).status;
            var follow = JSON.parse(xmlhttp.responseText).data;
            if (status == 400) {
                document.querySelector("#list>.subscribe>p").innerHTML = "0";
            } else {
                document.querySelector("#list>.subscribe>p").innerHTML = follow.length;
            }
        }
    }
}

function fanList(url, token, articleId) {
    if (token) {
        let xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET", url + "/follow/fansList", true);
        xmlhttp.setRequestHeader("Authorization", token);
        xmlhttp.send();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
                var status = JSON.parse(xmlhttp.responseText).status;
                var fan = JSON.parse(xmlhttp.responseText).data;
                if (status == 400) {
                    document.querySelector("#list>.fanNum>p").innerHTML = "0";
                } else {
                    document.querySelector("#list>.fanNum>p").innerHTML = fan.length;
                }
                return;
            }
        }
    }
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/follow/fansList?userId=" + articleId, true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var status = JSON.parse(xmlhttp.responseText).status;
            var fan = JSON.parse(xmlhttp.responseText).data;
            if (status == 400) {
                document.querySelector("#list>.fanNum>p").innerHTML = "0";
            } else {
                document.querySelector("#list>.fanNum>p").innerHTML = fan.length;
            }
        }
    }
}

function getUserArticle(url, articleId) {
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/article/getUserArticle?authorId=" + articleId + "&page=1&size=2", true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var status = JSON.parse(xmlhttp.responseText).status;
            let articleList = JSON.parse(xmlhttp.responseText).data.articleList;
            if (status == 400) {
                document.querySelector(".articleNum span").innerHTML = "0";
            } else {
                document.querySelector(".articleNum span").innerHTML = articleList.length;
            }
        }
    }
}