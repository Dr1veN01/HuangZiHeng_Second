function getDetails(url, articleId) {
    let xmlhttp = new XMLHttpRequest();
    let details = document.querySelector("#details .Box");
    details.innerHTML = "";
    xmlhttp.open("GET", url + "/article/getDetails?articleId=" + articleId, true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var data = JSON.parse(xmlhttp.responseText).data;
            console.log(data);
            if (!data.avatar) {
                data.avatar = "./img/noavater.jpg"
            }
            details.innerHTML += `
                <ul class="articleMsg">
                    <li><img src="${data.avatar}"></img></li>
                    <ul class="avatar" authorId=${data.authorId}>
                        <li class="username">${data.authorName}</li>
                        <li class="time">${data.time}</li>
                    </ul>
                    <li class="follow">关注</li>
                </ul>
                <div class="pic">
                    <ul>
                        <li><img
                                src="${data.img[0]}">
                        </li>
                    </ul>
                </div>
                <div class="content">${data.content}</div>
                <ul class="labels">
                    <li>#二次元</li>
                    <li>#神探夏洛克</li>
                </ul>
                <div class="function">
                    <div class="love iconfont">&#xe8ab;</div>
                    <div class="cmt iconfont">&#xe609;</div>
                </div>
                <ul class="allCmt">
                    <h3>热门评论</h3>
                    <ul>

                    </ul>
            `
            getReviewsByArt(url, articleId);
            document.querySelector("#main").style.display = "none";
            document.querySelector("#searchLine").style.display = "none"
            document.querySelector("#searchSection").style.display = "none"
            document.querySelector("#details").style.display = "block"
            document.querySelector("#downTags").style.display = "none"

            document.querySelector("#details .articleMsg .follow").addEventListener("click", function () {
                console.log("ok");
            })
        }
    }
}