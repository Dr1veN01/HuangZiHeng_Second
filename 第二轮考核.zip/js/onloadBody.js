function onloadBody(Body, url, type = "推荐") {
    // 初始化部分
    Body.innerHTML = "";
    if (type == '视频') return;

    // 利用Ajax向服务器申请数据
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/article/getArticle?type=" + type + "&page=1&size=15");
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var arr = JSON.parse(xmlhttp.responseText).data.articleList;
            addition(url, Body, arr, "#body", "#body>ul");
        }
    }
}

function addition(url, Body, arr, parent, child) {
    for (let i = 0; i < arr.length; i++) {
        var ul = document.createElement("ul");
        ul.setAttribute("articleId", arr[i].articleId)
        ul.setAttribute("authorId", arr[i].authorId)
        var Src = arr[i].cover;
        var img = new Image()
        img.src = Src;
        img.className = "cover";
        img.onload = function () {
            waterfall(parent, child);
        }
        ul.appendChild(img);
        if (!arr[i].avatar) {
            arr[i].avatar = "./img/noavater.jpg"
        }
        ul.innerHTML += `
                <li class="title">${arr[i].title}</li>
                <ul class="avatar">
                    <li><img src="${arr[i].avatar}"></img></li>
                    <li class="username">${arr[i].username}</li>
                    <li class="fanNum"><span class="ico iconfont">&#xe8ab;<span>${arr[i].fanNum}</li>
                </ul> 
            `
        ul.addEventListener("click", function () {
            let articledId = this.getAttribute("articleId")
            getDetails(url, articledId)
        })
        Body.appendChild(ul);;

    }
}