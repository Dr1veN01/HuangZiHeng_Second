window.onload = function () {
    const url = "http://175.178.4.54:3007";
    const Body = document.querySelector("#body");
    const token = sessionStorage.getItem("token")
    const articleId = sessionStorage.getItem("articleId");
    var AllImg = [];
    var i = 0;

    //进入网页加载主页文章
    onloadBody(Body, url);


    //upTag添加点击切换不同label事件
    const tags = document.querySelectorAll("#upTag li")
    for (let i = 0; i < tags.length; i++) {
        tags[i].addEventListener("click", function () {
            for (let j = 0; j < tags.length; j++) {
                tags[j].removeAttribute("class")
            }
            this.setAttribute("class", "current")
            let type = this.innerText;
            onloadBody(Body, url, type)
        })
    }

    // 搜索栏聚焦进入搜索模式
    const search = document.querySelector("#search input");
    const cancel = document.querySelector("#search .cancel")
    search.addEventListener("focus", function () {
        document.querySelector("#search").setAttribute("class", "searchChange");
        document.querySelector("#main").style.display = "none";
        document.querySelector("#searchSection").style.display = "block";
        cancel.style.display = "block";

    })
    //点击取消回到主页
    cancel.addEventListener("click", function () {
        document.querySelector("#search").removeAttribute("class")
        document.querySelector("#main").style.display = "block";
        document.querySelector("#searchSection").style.display = "none";
        cancel.style.display = "none";
    })
    // 点击ico进行搜索
    const searchClick = document.querySelector("#search .ico");
    searchClick.addEventListener("click", function () {
        var val = search.value;
        if (val == "") {
            alert("请输入搜索内容!");
            return;
        }
        document.querySelector("#recentSearch").style.display = "none";
        document.querySelector("#searchTags").style.display = "block";
        getArticleByKeyWord(url, val);
        searchTag[0].click();
    })
    // document.addEventListener("keydown", function (event) {
    //     if (event.key === "Enter") {
    //         searchClick.click();
    //     }
    // })
    // 切换searchTag切换搜索功能
    const searchTag = document.querySelectorAll("#searchTag>li");
    for (let i = 0; i < searchTag.length; i++) {
        searchTag[i].addEventListener("click", function () {
            var val = search.value;
            for (let j = 0; j < searchTag.length; j++) {
                searchTag[j].removeAttribute("class");
            }
            this.setAttribute("class", "searchCurrent");
            var species = this.innerText;
            if (species == "文章") {
                getArticleByKeyWord(url, val);
            } else if (species == "标签") {
                getLabel(url, val);
            } else if (species == "用户") {
                getUser(url, val);
            }
        })

    }


    //文章详情点击箭头返回首页
    const rtn = document.querySelector("#details .return")
    rtn.addEventListener("click", function () {
        downtags[0].click();
        document.querySelector("#downTags").style.display = "block"
    })


    //下方tag栏点击样式切换
    const downtags = document.querySelectorAll("#downTag li")
    for (let i = 0; i < downtags.length; i++) {
        downtags[i].addEventListener("click", function () {
            if (i == 2) return;
            if (i == 1 || i == 3) {
                alert("功能开发中!");
            } else if (i == 4) {
                //点击"我的"部分功能
                for (let j = 0; j < downtags.length; j++) {
                    downtags[j].removeAttribute("class")
                }
                this.setAttribute("class", "downCurrent")
                document.querySelector("#searchLine").style.display = "none";
                document.querySelector("#main").style.display = "none";
                document.querySelector("#details").style.display = "none";
                document.querySelector("#publishArticle").style.display = "none"
                document.querySelector("#searchSection").style.display = "none";
                //进入网页检测是否为登录状态
                loginCheck(url, token, articleId);
            } else if (i == 0) {
                //点击"首页"部分功能
                for (let j = 0; j < downtags.length; j++) {
                    downtags[j].removeAttribute("class")
                }
                this.setAttribute("class", "downCurrent")
                document.querySelector("#main").style.display = "block";
                document.querySelector("#searchLine").style.display = "block";
                document.querySelector("#downTags").style.display = "block";
                document.querySelector("#login").style.display = "none";
                document.querySelector("#mySection").style.display = "none";
                document.querySelector("#details").style.display = "none";
                document.querySelector("#publishArticle").style.display = "none"
                document.querySelector("#searchSection").style.display = "none";
                document.querySelector("#authorMsg").style.display = "none";
            }
        })
    }


    // 点击提交按钮登录
    var submit = document.querySelector("#submit");
    submit.addEventListener("click", function () {
        login(url);
    })




    //点击添加文章上传文章
    downtags[2].addEventListener("click", function () {
        if (!token) {
            alert("请先登录!");
            return;
        }
        document.querySelector("#login").style.display = "none";
        document.querySelector("#mySection").style.display = "none";
        document.querySelector("#main").style.display = "none";
        document.querySelector("#searchLine").style.display = "none"
        document.querySelector("#downTags").style.display = "none"
        document.querySelector("#publishArticle").style.display = "block"
    })

    // 点击左上角返回按钮
    document.querySelector("#publishArticle .return").addEventListener("click", function () {
        downtags[0].click();
    })

    //上传图片并将其显示在页面上
    const add = document.querySelector("#publishArticle #Add");
    add.addEventListener("change", function (e) {
        let file = e.target.files[0];
        AllImg[i] = file;
        i++;
        var reader = new FileReader();
        reader.readAsDataURL(file)
        reader.onload = function (res) {
            let src = this.result
            var img = new Image();
            img.src = src;
            var li = document.createElement("li");
            li.appendChild(img);
            document.querySelector(".AddPic ul").insertBefore(li, document.querySelector(".AddPic ul").children[0])
        }
    })

    //隐藏按钮并运行按钮事件
    const addbtn = document.querySelector("#publishArticle .Addbtn");
    addbtn.addEventListener("click", function () {
        add.click();
    })

    // 点击标签添加按钮添加标签事件
    const addLabel = document.querySelector(".addLabel");
    addLabel.addEventListener("click", function () {
        document.querySelector(".labelIpt").style.display = "block"
    })

    //点击取消按钮取消添加标签
    document.querySelector(".labelIpt>ul li:first-child").addEventListener("click", function () {
        document.querySelector(".labelIpt input").value = "";
        document.querySelector(".labelIpt").style.display = "none"
    })
    //点击确定按钮添加标签到页面
    document.querySelector(".labelIpt>ul li:last-child").addEventListener("click", function () {
        var label = document.querySelector(".labelIpt input").value;
        addlabel(label);
    })
    // 发布文章
    const publish = document.querySelector("#publish")
    publish.addEventListener("click", function () {
        let title = document.querySelector(".addTitle input").value;
        let content = document.querySelector(".AddArticle #content").value;
        let label = document.querySelectorAll(".addLabel ul>li");
        Publish(url, token, AllImg, title, content, label)
    })


    //个人主页点击返回回到主页
    document.querySelector("#authorMsg .return").addEventListener("click", function () {
        downtags[0].click();
    })


    //个人主页点击图片上传背景图片
    document.querySelector("#authorMsg #background").addEventListener("click", function () {
        document.querySelector("#authorMsg #backgroundImg").click();
    })
    document.querySelector("#authorMsg #backgroundImg").addEventListener("change", function (e) {
        if (document.querySelector("#authorMsg").getAttribute("authorId") == articleId) {
            let file = e.target.files[0];
            uploadBackground(url, token, file);
        } else {
            return;
        }

    })

    //个人主页点击头像上传头像
    document.querySelector("#authorMsg #msgBody .Avatar").addEventListener("click", function () {
        document.querySelector("#authorMsg #avatarImg").click();
    })
    document.querySelector("#authorMsg #avatarImg").addEventListener("change", function (e) {
        if (document.querySelector("#authorMsg").getAttribute("authorId") == articleId) {
            let file = e.target.files[0];
            uploadAvatar(url, token, file);
        } else {
            alert("bad")
            return;
        }

    })
}
