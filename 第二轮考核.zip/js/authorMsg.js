function author_getUserInfo(url, ID) {
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/userInfo/getUserInfo?id=" + ID, true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var data = JSON.parse(xmlhttp.responseText).data;
            document.querySelector("#authorMsg").setAttribute("authorId", ID)
            document.querySelector("#authorMsg #msgBody .Avatar img").src = data.avatar;
            document.querySelector("#authorMsg #background img").src = data.background_img;
            if (!data.avatar) {
                document.querySelector("#authorMsg #msgBody .Avatar img").src = "./img/noavater.jpg";
            }
            if (!data.background_img) {
                document.querySelector("#authorMsg #background img").src = "./img/fav.jpg";
            }
            document.querySelector("#authorMsg #authorContainer h3").innerHTML = data.username;
            document.querySelector("#authorMsg #authorContainer div").innerHTML = "ID:" + ID;
        }
    }
}

function author_followList(url, ID) {
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/follow/followList?userId=" + ID, true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var status = JSON.parse(xmlhttp.responseText).status;
            var follow = JSON.parse(xmlhttp.responseText).data;
            if (status == 400) {
                document.querySelector("#authorMsg .authorList li:first-child p").innerHTML = "0";
            } else {
                document.querySelector("#authorMsg .authorList li:first-child p").innerHTML = follow.length;
            }
        }
    }
}

function author_fanList(url, ID) {
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url + "/follow/fansList?userId=" + ID, true);
    xmlhttp.send();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var status = JSON.parse(xmlhttp.responseText).status;
            var fan = JSON.parse(xmlhttp.responseText).data;
            if (status == 400) {
                document.querySelector("#authorMsg .authorList li:nth-child(2) p").innerHTML = "0";
            } else {
                document.querySelector("#authorMsg .authorList li:nth-child(2) p").innerHTML = fan.length;
            }
        }
    }
}

function uploadBackground(url, token, file) {
    let formdata = new FormData();
    let xmlhttp = new XMLHttpRequest()
    formdata.append("background_img", file)
    xmlhttp.open("POST", url + "/userInfo/uploadBackground", true);
    xmlhttp.setRequestHeader("Authorization", token);
    xmlhttp.send(formdata);
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            alert("上传成功!");
        }
    }

}

function uploadAvatar(url, token, file) {
    let formdata = new FormData();
    let xmlhttp = new XMLHttpRequest()
    formdata.append("avatar", file)
    xmlhttp.open("POST", url + "/userInfo/uploadAvatar", true);
    xmlhttp.setRequestHeader("Authorization", token);
    xmlhttp.send(formdata);
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            alert("上传成功!");
        }
    }
}